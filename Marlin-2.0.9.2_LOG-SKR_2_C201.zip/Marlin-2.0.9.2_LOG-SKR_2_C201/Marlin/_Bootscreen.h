/**
 * Made with Marlin Bitmap Converter
 * https://marlinfw.org/tools/u8glib/converter.html
 *
 * This bitmap from the file 'Sin título-1.png'
 */
#pragma once

#define CUSTOM_BOOTSCREEN_BMPWIDTH  64

const unsigned char custom_start_bmp[] PROGMEM = {
 /**Custom Bootscreen Bitmap*/
};
